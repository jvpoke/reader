export const coverPlaceholderColor = '#8888881F';

export const filterColor: (isDark: boolean) => string = isDark =>
  isDark ? '#FFC107' : '#FFC107';
