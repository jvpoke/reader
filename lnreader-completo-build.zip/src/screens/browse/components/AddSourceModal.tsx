import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { Modal, Portal, TextInput, Button, Text } from 'react-native-paper';
import { ThemeColors } from '../../../theme/types';
import { useAppDispatch } from '../../../redux/hooks';
import { addUserSource, getSourcesAction } from '../../../redux/source/sourcesSlice';

interface AddSourceModalProps {
  visible: boolean;
  onDismiss: () => void;
  theme: ThemeColors;
}

const AddSourceModal: React.FC<AddSourceModalProps> = ({
  visible,
  onDismiss,
  theme,
}) => {
  const dispatch = useAppDispatch();
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [lang, setLang] = useState('English');

  const onAdd = () => {
    if (name && url) {
      const newSource = {
        sourceId: Date.now(),
        sourceName: name,
        url: url,
        lang: lang,
        icon: 'https://raw.githubusercontent.com/LNReader/lnreader-sources/main/icons/multisrc/madara/icons/noveltranslate.png', // Default icon
      };
      dispatch(addUserSource(newSource));
      dispatch(getSourcesAction());
      setName('');
      setUrl('');
      onDismiss();
    }
  };

  return (
    <Portal>
      <Modal
        visible={visible}
        onDismiss={onDismiss}
        contentContainerStyle={[
          styles.container,
          { backgroundColor: theme.surface },
        ]}
      >
        <Text style={[styles.title, { color: theme.onSurface }]}>Add Manual Source</Text>
        <TextInput
          label="Source Name"
          value={name}
          onChangeText={setName}
          mode="outlined"
          style={styles.input}
          theme={{ colors: { primary: theme.primary } }}
        />
        <TextInput
          label="Source URL"
          value={url}
          onChangeText={setUrl}
          mode="outlined"
          style={styles.input}
          theme={{ colors: { primary: theme.primary } }}
        />
        <TextInput
          label="Language"
          value={lang}
          onChangeText={setLang}
          mode="outlined"
          style={styles.input}
          theme={{ colors: { primary: theme.primary } }}
        />
        <View style={styles.buttonContainer}>
          <Button onPress={onDismiss} textColor={theme.primary}>
            Cancel
          </Button>
          <Button onPress={onAdd} mode="contained" style={{ backgroundColor: theme.primary }}>
            Add
          </Button>
        </View>
      </Modal>
    </Portal>
  );
};

export default AddSourceModal;

const styles = StyleSheet.create({
  container: {
    padding: 20,
    margin: 20,
    borderRadius: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    marginBottom: 12,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 16,
  },
});
