declare module '@env' {
  export const MYANIMELIST_CLIENT_ID: string;
  export const ANILIST_CLIENT_ID: string;
}
