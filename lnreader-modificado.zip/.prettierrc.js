module.exports = {
  tabWidth: 2,
  bracketSpacing: true,
  useTabs: false,
  bracketSameLine: false,
  singleQuote: true,
  trailingComma: 'all',
  arrowParens: 'avoid',
  quoteProps: 'preserve',
};
