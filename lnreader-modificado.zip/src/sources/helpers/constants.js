export const defaultCoverUri =
  'https://github.com/LNReader/lnreader-sources/blob/main/icons/src/coverNotAvailable.jpg?raw=true';

export const Status = {
  ONGOING: 'Ongoing',
  COMPLETED: 'Completed',
  UNKNOWN: 'Unknown',
};
