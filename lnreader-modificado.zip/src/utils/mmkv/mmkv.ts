import { MMKV } from 'react-native-mmkv';

export const MMKVStorage = new MMKV();
