export const appVersion = '1.1.18';
export const releaseDate = '09/10/23 11:00 AM';
