import { SectionList, StyleSheet, Text } from 'react-native';
import React, { useCallback, useEffect, useMemo, useState } from 'react';

import { EmptyView, SearchbarV2 } from '../../components';
import {
  defaultLanguage,
  getSourcesAction,
  searchSourcesAction,
  setLastUsedSource,
  togglePinSource,
  removeUserSource,
} from '../../redux/source/sourcesSlice';
import AddSourceModal from './components/AddSourceModal';
import { Alert } from 'react-native';
import {
  useAppDispatch,
  useBrowseSettings,
  useSourcesReducer,
} from '../../redux/hooks';
import { useTheme } from '@hooks/useTheme';
import { useNavigation } from '@react-navigation/native';
import { useSearch } from '../../hooks';
import SourceCard from './components/SourceCard/SourceCard';
import { getString } from '../../../strings/translations';
import { Source } from '../../sources/types';
import TrackerCard from './discover/TrackerCard';

const BrowseScreen = () => {
  const { navigate } = useNavigation();
  const theme = useTheme();
  const dispatch = useAppDispatch();

  const { searchText, setSearchText, clearSearchbar } = useSearch();

  const onChangeText = (text: string) => {
    setSearchText(text);
    dispatch(searchSourcesAction(text));
  };

  const handleClearSearchbar = () => {
    clearSearchbar();
    dispatch(getSourcesAction());
  };

  const {
    allSources,
    searchResults,
    pinnedSourceIds = [],
    languageFilters = [defaultLanguage || 'English'], //defaultLang cant be null, but just for sure
    lastUsed,
    userSources = [],
  } = useSourcesReducer();

  const {
    showMyAnimeList = true,
    showAniList = true,
    onlyShowPinnedSources = false,
  } = useBrowseSettings();

  const [addSourceModalVisible, setAddSourceModalVisible] = useState(false);

  useEffect(() => {
    dispatch(getSourcesAction());
  }, [dispatch, languageFilters]);

  const isPinned = (sourceId: number) => pinnedSourceIds.indexOf(sourceId) > -1;

  const pinnedSources = allSources.filter(source => isPinned(source.sourceId));
  const lastUsedSource = lastUsed
    ? allSources.filter(source => source.sourceId === lastUsed)
    : [];

  const navigateToSource = useCallback(
    (source: Source, showLatestNovels?: boolean) => {
      navigate(
        'SourceScreen' as never,
        {
          sourceId: source.sourceId,
          sourceName: source.sourceName,
          url: source.url,
          showLatestNovels,
        } as never,
      );
      dispatch(setLastUsedSource({ sourceId: source.sourceId }));
    },
    [],
  );

  const onLongPressSource = (source: Source) => {
    if (userSources.some(s => s.sourceId === source.sourceId)) {
      Alert.alert(
        'Remove Source',
        `Are you sure you want to remove ${source.sourceName}?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Remove',
            style: 'destructive',
            onPress: () => {
              dispatch(removeUserSource(source.sourceId));
              dispatch(getSourcesAction());
            },
          },
        ],
      );
    }
  };

  const searchbarActions = useMemo(
    () => [
      {
        iconName: 'plus',
        onPress: () => setAddSourceModalVisible(true),
      },
      {
        iconName: 'book-search',
        onPress: () => navigate('GlobalSearchScreen' as never),
      },
      {
        iconName: 'swap-vertical-variant',
        onPress: () => navigate('Migration' as never),
      },
      {
        iconName: 'cog-outline',
        onPress: () => navigate('BrowseSettings' as never),
      },
    ],
    [],
  );

  const sections = useMemo(() => {
    const list = [
      {
        header: getString('browseScreen.lastUsed'),
        data: lastUsedSource,
      },
    ];

    if (pinnedSourceIds) {
      list.push({
        header: getString('browseScreen.pinned'),
        data: pinnedSources,
      });
    }

    if (!onlyShowPinnedSources) {
      if (searchText) {
        list.unshift({
          header: getString('common.searchResults'),
          data: searchResults,
        });
      } else {
        list.push({
          header: getString('browseScreen.all'),
          data: allSources,
        });
      }
    }

    return list;
  }, [
    lastUsedSource,
    pinnedSourceIds,
    onlyShowPinnedSources,
    JSON.stringify(searchResults),
    searchText,
  ]);

  return (
    <>
      <SearchbarV2
        searchText={searchText}
        placeholder={getString('browseScreen.searchbar')}
        leftIcon="magnify"
        onChangeText={onChangeText}
        clearSearchbar={handleClearSearchbar}
        theme={theme}
        rightIcons={searchbarActions}
      />
      <AddSourceModal
        visible={addSourceModalVisible}
        onDismiss={() => setAddSourceModalVisible(false)}
        theme={theme}
      />
      {languageFilters.length === 0 ? (
        <EmptyView
          icon="(･Д･。"
          description={getString('browseScreen.listEmpty')}
          theme={theme}
        />
      ) : allSources.length === 0 ? null : (
        <>
          <SectionList
            sections={sections}
            ListHeaderComponent={
              showMyAnimeList ? (
                <>
                  <Text
                    style={[
                      styles.sectionHeader,
                      { color: theme.onSurfaceVariant },
                    ]}
                  >
                    {getString('browseScreen.discover')}
                  </Text>
                  {showAniList && (
                    <TrackerCard
                      theme={theme}
                      icon={require('../../../assets/anilist.png')}
                      navTarget="BrowseAL"
                      trackerName="AniList"
                    />
                  )}
                  {showMyAnimeList && (
                    <TrackerCard
                      theme={theme}
                      icon={require('../../../assets/mal.png')}
                      navTarget="BrowseMal"
                      trackerName="MyAnimeList"
                    />
                  )}
                </>
              ) : null
            }
            keyExtractor={(_, index) => index.toString()}
            renderSectionHeader={({ section: { header, data } }) =>
              data.length > 0 ? (
                <Text
                  style={[
                    styles.sectionHeader,
                    { color: theme.onSurfaceVariant },
                  ]}
                >
                  {header}
                </Text>
              ) : null
            }
            renderItem={({ item }) => (
              <SourceCard
                source={item}
                isPinned={isPinned(item.sourceId)}
                navigateToSource={navigateToSource}
                onTogglePinSource={sourceId =>
                  dispatch(togglePinSource(sourceId))
                }
                onLongPress={onLongPressSource}
                theme={theme}
              />
            )}
          />
        </>
      )}
    </>
  );
};

export default BrowseScreen;

const styles = StyleSheet.create({
  sectionHeader: {
    fontSize: 14,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
});
