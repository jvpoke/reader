export interface BrowseSettingsMap {
  onlyShowPinnedSources: 'string';
  searchAllSources: 'string';
  showMyAnimeList: 'string';
  showAniList: 'string';
}
