import { load as loadCheerio } from 'cheerio';

export const translateText = async (text: string, from: string = 'auto', to: string = 'pt'): Promise<string> => {
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${from}&tl=${to}&dt=t&q=${encodeURIComponent(text)}`;
    const response = await fetch(url);
    const data = await response.json();
    return data[0].map((item: any) => item[0]).join('');
  } catch (error) {
    console.error('Translation error:', error);
    return text;
  }
};

export const translateHtml = async (html: string): Promise<string> => {
  const $ = loadCheerio(html);
  
  // Traduzir parágrafos
  const paragraphs = $('p').toArray();
  for (const p of paragraphs) {
    const originalText = $(p).text();
    if (originalText.trim()) {
      const translatedText = await translateText(originalText);
      $(p).text(translatedText);
    }
  }

  // Traduzir títulos
  const headers = $('h1, h2, h3, h4, h5, h6').toArray();
  for (const h of headers) {
    const originalText = $(h).text();
    if (originalText.trim()) {
      const translatedText = await translateText(originalText);
      $(h).text(translatedText);
    }
  }

  return $.html();
};
